package cz.cvut.fel.archval.core.api.model.report;

/**
 * Supertype for all nodes of result tree.
 * 
 * @author Martin Vejmelka (martin.vejmelka@fel.cvut.cz)
 */
public abstract class ResultNode {
}
