package cz.cvut.fel.archval.core.valgen.symbol;

/**
 * Kind of rule symbol name.
 * 
 * @author Martin Vejmelka (martin.vejmelka@fel.cvut.cz)
 */
public enum RuleNameSymbolKind {

    ATOMIC_RULE_NAME, COMPOUND_RULE_NAME

}
